import tkinter as tk

# Sample data structure to store employee details
Employee_details = {
    "101": {
        "Name": "gangalakshmi",
        
        "Department":"Software engineering",
        "Work location":"Bengaluru",
        "Company name":"Infosys",
        "Salary": 50000,
        "Email":"gangalakshmi@gmail.com",
        "Phone number":1237894561

    },
    "102": {
        "Name": "premika",
         
        "Department": "Bank manager",
        "Work location":"Vizag",
        "Company name":"State bank",
        "Salary": 45000,
        "Email":"premika@gmail.com",
        "Phone number":8745814526
    },
    "103":{
       "Name": "Satya",
         
        "Department": "Statistics",
        "Work location":"Hyderabad",
        "Company name":"Accenture",
        "Salary": 35000,
        "Email":"satya@gmail.com",
        "Phone number": 6320723156
    },
    "104":{
        "Name": "vennela",
         
        "Department": "Lecture",
        "Work location":"Rajamundry",
        "Company name":"Arts",
        "Salary": 40000,
        "Email":"vennela@gmail.com",
        "Phone number":1532467895
    },
}

def display_Employee_details():
    Employee_id = entry_id.get()
    if Employee_id in Employee_details:
        details = Employee_details[Employee_id]
        output_label.config(text=f"Name: {details['Name']}\nDepartment: {details['Department']}\nWork location: {details['Work location']}\nCompany name: {details['Company name']}\nSalary: {details['Salary']}\nEmail: {details['Email']}\nPhone number: {details['Phone number']}")
    else:
        output_label.config(text="Employee not found.")

# Create the main application window
root = tk.Tk()
root.title("Employee Details")

# Create input widgets
label_id = tk.Label(root, text="Enter Employee ID:",width=50)
label_id.pack()

entry_id = tk.Entry(root)
entry_id.pack()

submit_button = tk.Button(root, text="Submit", command=display_Employee_details,width=20)
submit_button.pack()

# Create the output label
output_label = tk.Label(root, text="", justify=tk.LEFT)
output_label.pack()

# Start the application event loop
root.mainloop()